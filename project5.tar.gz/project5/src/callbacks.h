#include <gtk/gtk.h>

void
on_refresh_cl_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajouter_cl1_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_cl_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_supprimer_cl_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_r_cin_cl_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ajouter_ag_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_ag_clicked                   (GtkButton       *button,
                                        gpointer         user_data);


void
on_ajouter_cl_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_modif_cl_show                       (GtkWidget       *widget,
                                        gpointer         user_data);
