#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "agent.h"


void
on_refresh_cl_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *espace_ag;
espace_ag=lookup_widget(button,"espace_ag");
gtk_widget_hide(espace_ag);
espace_ag = create_espace_ag ();
gtk_widget_show (espace_ag);
GtkWidget *treeview2;
treeview2=lookup_widget(espace_ag,"treeview2");
afficher_personne_cl(treeview2);
}


void
on_ajouter_cl1_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajout_cl ;
ajout_cl = create_ajout_cl ();
gtk_widget_show (ajout_cl);
}


void
on_modifier_cl_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char cin[50];
GtkWidget *Combobox2;
Combobox2 = lookup_widget(objet_graphique,"combobox2");
if(gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox2))!= NULL)
	{
	strcpy(cin,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox2)));
	XX(cin);
	GtkWidget *modif_cl ;
	modif_cl = create_modif_cl ();
	gtk_widget_show(modif_cl);
	}
}


void
on_supprimer_cl_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char cin[50];
GtkWidget *Combobox2;
Combobox2 = lookup_widget(objet_graphique,"combobox2");
if(gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox2))!= NULL)
	{
	strcpy(cin , gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox2)));
	supprimerm(cin);
	}
}


void
on_r_cin_cl_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
int n,i;
char cins[50][50];
GtkWidget *Combobox2;
Combobox2=lookup_widget(objet_graphique,"combobox2");
n=combo2(cins); 

for(i=0;i<n;i++)
{
gtk_combo_box_append_text(GTK_COMBO_BOX(Combobox2),_(cins[i]));
}
}


void
on_ajouter_ag_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
int x;
GtkWidget	*input_nom	=	lookup_widget(objet,"entry021");
GtkWidget	*input_prenom	=	lookup_widget(objet,"entry022");
GtkWidget	*input_cin	=	lookup_widget(objet,"entry023");
GtkWidget	*input_gsm	=	lookup_widget(objet,"entry024");
GtkWidget	*input_adresse	=	lookup_widget(objet,"entry025");
GtkWidget	*input_date	=	lookup_widget(objet,"entry026");
GtkWidget	*input_mdp	=	lookup_widget(objet,"entry027");
GtkWidget	*input_cmdp	=	lookup_widget(objet,"entry028");
Personne p;
char cmdp[50];
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input_nom)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input_prenom)));
strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input_cin)));
strcpy(p.gsm,gtk_entry_get_text(GTK_ENTRY(input_gsm)));
strcpy(p.adresse,gtk_entry_get_text(GTK_ENTRY(input_adresse)));
strcpy(p.date_naissance,gtk_entry_get_text(GTK_ENTRY(input_date)));
strcpy(p.mot_de_passe,gtk_entry_get_text(GTK_ENTRY(input_mdp)));
strcpy(cmdp,gtk_entry_get_text(GTK_ENTRY(input_cmdp)));
x=verif(p.cin);
if (x==0)
	{
		if(strcmp(cmdp,p.mot_de_passe)==0)
			{
			ajouter(p);
			GtkWidget *ajout_cl;
			ajout_cl=lookup_widget(objet,"ajout_cl");
			gtk_widget_hide(ajout_cl);
			}
		else
			{
			GtkWidget *output5=lookup_widget(objet,"label01");
			gtk_label_set_text(GTK_LABEL(output5),"verifier mot de passe");
			}
	}
else
	{
	GtkWidget *output5=lookup_widget(objet,"label01");
	gtk_label_set_text(GTK_LABEL(output5),"changer cin");
	}
}


void
on_retour_ag_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajout_cl ;
ajout_cl=lookup_widget(button,"ajout_cl");
gtk_widget_hide(ajout_cl);
}

void
on_ajouter_cl_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
Personne p;
int x;
p=YY();
GtkWidget	*input_nom	=	lookup_widget(button,"entry031");
GtkWidget	*input_prenom	=	lookup_widget(button,"entry032");
GtkWidget	*input_cin	=	lookup_widget(button,"entry033");
GtkWidget	*input_gsm	=	lookup_widget(button,"entry034");
GtkWidget	*input_adresse	=	lookup_widget(button,"entry035");
GtkWidget	*input_date	=	lookup_widget(button,"entry036");
GtkWidget	*input_mdp	=	lookup_widget(button,"entry037");
GtkWidget	*input_cmdp	=	lookup_widget(button,"entry038");
char cmdp[50];
strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input_nom)));
strcpy(p.prenom,gtk_entry_get_text(GTK_ENTRY(input_prenom)));
strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input_cin)));
strcpy(p.gsm,gtk_entry_get_text(GTK_ENTRY(input_gsm)));
strcpy(p.adresse,gtk_entry_get_text(GTK_ENTRY(input_adresse)));
strcpy(p.date_naissance,gtk_entry_get_text(GTK_ENTRY(input_date)));
strcpy(p.mot_de_passe,gtk_entry_get_text(GTK_ENTRY(input_mdp)));
strcpy(cmdp,gtk_entry_get_text(GTK_ENTRY(input_cmdp)));
if(strcmp(cmdp,p.mot_de_passe)==0)
	{
	ZZ(p);
	remove("tamp.txt");
	GtkWidget *modif_cl;
	modif_cl=lookup_widget(button,"modif_cl");
	gtk_widget_hide(modif_cl);
	}
else
	{
	GtkWidget *output5=lookup_widget(button,"label03");
	gtk_label_set_text(GTK_LABEL(output5),"verifier mot de passe");
	}
}


void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modif_cl ;
modif_cl=lookup_widget(button,"modif_cl");
gtk_widget_hide(modif_cl);
}


void
on_modif_cl_show                       (GtkWidget       *widget,
                                        gpointer         user_data)
{
Personne p;
p=YY();
GtkWidget	*input_nom	=	lookup_widget(widget,"entry031");
GtkWidget	*input_prenom	=	lookup_widget(widget,"entry032");
GtkWidget	*input_cin	=	lookup_widget(widget,"entry033");
GtkWidget	*input_gsm	=	lookup_widget(widget,"entry034");
GtkWidget	*input_adresse	=	lookup_widget(widget,"entry035");
GtkWidget	*input_date	=	lookup_widget(widget,"entry036");
GtkWidget	*input_mdp	=	lookup_widget(widget,"entry037");
GtkWidget	*input_cmdp	=	lookup_widget(widget,"entry038");
gtk_entry_set_text (GTK_ENTRY (input_nom), _(p.nom));
gtk_entry_set_text (GTK_ENTRY (input_prenom), _(p.prenom));
gtk_entry_set_text (GTK_ENTRY (input_cin), _(p.cin));
gtk_entry_set_text (GTK_ENTRY (input_gsm), _(p.gsm));
gtk_entry_set_text (GTK_ENTRY (input_adresse), _(p.adresse));
gtk_entry_set_text (GTK_ENTRY (input_date), _(p.date_naissance));
gtk_entry_set_text (GTK_ENTRY (input_mdp), _(p.mot_de_passe));
gtk_entry_set_text (GTK_ENTRY (input_cmdp), _(p.mot_de_passe));
}

